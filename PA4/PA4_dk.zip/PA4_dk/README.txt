Contact: dhko9143@colorado.edu

Run ./test-predict OR ./test-lru
Don't open results.txt and serviced.txt in notepad as formatting is off. Notepad++ or similar displays them fine.

PA4/Makefile: Contains instructions on how to compile and build the pager implementations.
PA4/pager-lru.c: code for the lru pager implementation.
PA4/predict.h: header for the predictive pager implementation program containing variable macros and functions for recording process history.
PA4/pager-predict.c: code for the predictive pager implementation
Inspiration for the predictive pager implementation came from Andy Sayler <andy.sayler@gmail.com>  