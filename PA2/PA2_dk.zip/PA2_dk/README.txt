Contact: dhko9143@colorado.edu


modules/Makefile: Contains instructions on how to compile and build the device driver module.

modules/simple_char_driver.c: code for the character device driver module.

simple_char_driver_test.c: Test program to test the character device driver.